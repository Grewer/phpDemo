/**
 * author   Grewer
 * date		17.3.14
 * 
 */
$(function(){
	$('.zu-top-nav-userinfo,.top-nav-dropdown').on('mouseout mouseover',function(){
		$('#top-nav-profile-dropdown').toggle();
	});

	
});